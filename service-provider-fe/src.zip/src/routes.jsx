import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home.jsx";
import About from "./components/About.jsx";
import Login from "./components/Auth/Login.jsx";
import Register from "./components/Auth/Registration.jsx";
import Profile from "./components/Profile/Profile.jsx";
import BookingList from "./components/Bookings/BookingList.jsx";
import ServiceList from "./components/Services/ServiceList.jsx";
import Testimonials from './components/Testimonials/Testimonials';
import Contact from './components/Contact/Contact';
import HomeServices from './components/Services/HomeServices';
import CleaningServices from './components/Services/CleaningServices';
import PersonalServices from './components/Services/PersonalServices';
import SolarServices from './components/Services/SolarServices';
import HomeInspections from './components/Services/HomeInspections';

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/about" element={<About />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/services" element={<ServiceList />} />
    <Route path="/bookings" element={<BookingList />} />
    <Route path="/profile" element={<Profile />} />
    <Route path="/testimonials" element={<Testimonials />} />
    <Route path="/contact" element={<Contact />} />
    <Route path="/services/home/:id" element={<HomeServices />} />
    <Route path="/services/cleaning/:id" element={<CleaningServices />} />
    <Route path="/services/personal/:id" element={<PersonalServices />} />
    <Route path="/services/solar/:id" element={<SolarServices />} />
    <Route path="/services/inspection/:id" element={<HomeInspections />} />
  </Routes>
);

export default AppRoutes;
