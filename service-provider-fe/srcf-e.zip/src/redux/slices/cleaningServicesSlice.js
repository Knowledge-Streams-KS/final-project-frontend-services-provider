import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import * as api from '../../utils/api.js';

export const fetchCleaningServices = createAsyncThunk('cleaningServices/fetchCleaningServices', async () => {
  const response = await api.get('/cleaningServices');
  return response.data;
});

const cleaningServicesSlice = createSlice({
  name: 'cleaningServices',
  initialState: {
    services: [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCleaningServices.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchCleaningServices.fulfilled, (state, action) => {
        state.services = action.payload;
        state.loading = false;
      })
      .addCase(fetchCleaningServices.rejected, (state, action) => {
        state.error = action.error.message;
        state.loading = false;
      });
  },
});

export default cleaningServicesSlice.reducer;
